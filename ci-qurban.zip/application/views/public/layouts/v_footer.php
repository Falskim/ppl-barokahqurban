    <a href="#" id="scroll-to-top" class="dmtop global-radius"><i class="fa fa-angle-up"></i></a>

    <!-- ALL JS FILES -->
    <script src="<?= base_url('assets/user/js/all.js'); ?>"></script>
    <!-- ALL PLUGINS -->
    <script src="<?= base_url('assets/user/js/custom.js'); ?>"></script>
    <script src="<?= base_url('assets/user/js/portfolio.js'); ?>"></script>
    <script src="<?= base_url('assets/user/js/hoverdir.js'); ?>"></script>    
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>    
    <script>
        $(document).ready( function () {
            $('#dataTable').DataTable();
        });
    </script>
</body>
</html>