# CI-QURBAN

Codeigniter Framework Website

## Installation

1. [Download](https://github.com/Falskim/ci-qurban/archive/master.zip) or clone this project repository
2. If you're using XAMPP, extract the folder to *htdocs*
3. Start Apache and MySQL service from XAMPP
4. Access ```http://localhost/phpmyadmin```, then create database **qurban**
5. Import database dump file *db/qurban.sql*
6. Access ```http://localhost/ci-qurban``` with your browser

## Usage

Login :
- **admin** as username and password for admin privilege
- **user@gmail.com** or **user2@gmail.com** as username and **user** as password for user privileges 